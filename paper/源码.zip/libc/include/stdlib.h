#ifndef _STDLIB_H
#define _STDLIB_H

int rand(void);

#endif // _STDLIB_H
