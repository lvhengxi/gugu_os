#ifndef _STDDEF_H
#define _STDDEF_H

typedef unsigned int size_t;

#endif // _STDDEF_H
