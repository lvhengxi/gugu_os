#include "api.h"

int main(void) {
  api_putchar('h');
  api_putchar('e');
  api_putchar('l');
  api_putchar('l');
  api_putchar('o');

  api_end();

  return 0;
}
