#include "api.h"

int main() {
  api_putstr("hello world\n");
  api_end();

  return 0;
}
