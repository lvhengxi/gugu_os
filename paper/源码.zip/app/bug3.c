#include "api.h"

int main(void) {
  for (;;) {
    api_putchar('a');
  }

  return 0;
}
