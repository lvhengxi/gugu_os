int main() {
  for (;;) {}

  return 0;
}
