#include "api.h"

int main(void) {
  api_putchar('A');
  
  api_end();

  return 0;
}
